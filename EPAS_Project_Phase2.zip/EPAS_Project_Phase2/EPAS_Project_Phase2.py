#!/usr/bin/env python
# coding: utf-8

# In[57]:


#simulation 7

#!pip install igraph 
import matplotlib.pyplot as plt
import networkx as nx
import louvain
import numpy as np
import scipy as scp
import matplotlib.pyplot as plt
import networkx as nx
import igraph as ig

G = nx.Graph()
node_list = [item for item in range(0, 16)]
G.add_nodes_from(node_list)
edge = [(node_list[0],node_list[2]),(node_list[0],node_list[3]),(node_list[0],node_list[4]),(node_list[0],node_list[5]),
        (node_list[1],node_list[2]),(node_list[1],node_list[4]),(node_list[1],node_list[7]),(node_list[2],node_list[4]),
        (node_list[2],node_list[5]),(node_list[2],node_list[6]),(node_list[3],node_list[7]),(node_list[4],node_list[10]),
        (node_list[5],node_list[7]),(node_list[5],node_list[11]),(node_list[6],node_list[7]),(node_list[6],node_list[11]),
        (node_list[8],node_list[11]),(node_list[8],node_list[9]),(node_list[8],node_list[15]),(node_list[8],node_list[10]),
        (node_list[8],node_list[14]),(node_list[9],node_list[12]),(node_list[9],node_list[14]),(node_list[10],node_list[11]),
        (node_list[10],node_list[12]),(node_list[10],node_list[13]),(node_list[10],node_list[14]),(node_list[11],node_list[13])]

G.add_edges_from(edge)
nx.draw(G,node_color='SlateGray', with_labels=True)
plt.show()
G2 = ig.Graph.from_networkx(G)
partition = louvain.find_partition(G2, louvain.ModularityVertexPartition)
print(partition)
for i in range(len(partition)):
  print(partition[i])


# In[62]:


#simulation 8

#!pip install igraph 
import matplotlib.pyplot as plt
import networkx as nx
import louvain
import numpy as np
import scipy as scp
import matplotlib.pyplot as plt
import networkx as nx
import igraph as ig

G = nx.Graph()
node_list = [item for item in range(0, 16)]
G.add_nodes_from(node_list)
edge = [(node_list[0],node_list[2]),(node_list[0],node_list[3]),(node_list[0],node_list[4]),(node_list[0],node_list[5]),
        (node_list[1],node_list[2]),(node_list[1],node_list[4]),(node_list[1],node_list[7]),(node_list[2],node_list[4]),
        (node_list[2],node_list[5]),(node_list[2],node_list[6]),(node_list[3],node_list[7]),(node_list[4],node_list[10]),
        (node_list[5],node_list[7]),(node_list[5],node_list[11]),(node_list[6],node_list[7]),(node_list[6],node_list[11]),
        (node_list[8],node_list[11]),(node_list[8],node_list[9]),(node_list[8],node_list[15]),(node_list[8],node_list[10]),
        (node_list[8],node_list[14]),(node_list[9],node_list[12]),(node_list[9],node_list[14]),(node_list[10],node_list[11]),
        (node_list[10],node_list[12]),(node_list[10],node_list[13]),(node_list[10],node_list[14]),(node_list[11],node_list[13])]

G.add_edges_from(edge)
nx.draw(G,node_color='SlateGray', with_labels=True)
plt.show()
G2 = ig.Graph.from_networkx(G)
partition = louvain.find_partition(G2, louvain.RBConfigurationVertexPartition)
print(partition)
for i in range(len(partition)):
  print(partition[i])


# In[61]:


#simulation 9

import community as community_louvain
import matplotlib.cm as cm
import matplotlib.pyplot as plt
import networkx as nx

# load the karate club graph
G = nx.karate_club_graph()

plt.figure("1")
nx.draw(G,node_color='SlateGray', with_labels=True)
plt.show()

#first compute the best partition
partition = community_louvain.best_partition(G)

# draw the graph
pos = nx.spring_layout(G)
# color the nodes according to their partition
cmap = cm.get_cmap('viridis', max(partition.values()) + 1)
nx.draw_networkx_nodes(G, pos, partition.keys(), node_size=40,
                       cmap=cmap, node_color=list(partition.values()))
nx.draw_networkx_edges(G, pos, alpha=0.5)
plt.show()


# In[ ]:
#!/usr/bin/env python
# coding: utf-8

# In[61]:


import networkx as nx
import math
import scipy.special as ss

men_num = 6
women_num = 3
a = float(input("a  =   "))
m1 = 10
m2 = 3
m12 = 5

#g_men = men_num*(men_num - 1)/2
g_women = women_num*(women_num - 1)/2
men_women = men_num*women_num

#p_men = m1/g_men
p_women = m2/g_women
p_men_women = m12/men_women

#s1 = math.sqrt(2*p_men*(1-p_men)/(men_num*(men_num-1)))
s2 = math.sqrt(2*p_women*(1-p_women)/(women_num*(women_num-1)))
s3 = math.sqrt(p_men_women*(1-p_men_women)/(p_men*p_women))

#w1 = m12/men_women - m1/g_men
w2 = m12/men_women - m2/g_women

e = 2*a*math.sqrt(2)
fi = ss.erfinv(1 - e)

# In[ ]:


# !/usr/bin/env python
# coding: utf-8

# In[27]:


import numpy as np
import random
import matplotlib.pyplot as plt
import networkx as nx


# In[25]:


def path_lengths(G):  # calculate path length of a graph
    length_map = nx.shortest_path_length(G)
    lengths = [length_map[u][v] for u, v in all_pairs(G)]
    return lengths


# # Simulation 1

# <p dir="rtl">
#    در این پرسش از ما خواسته شده است که نمونه ای ازگراف watts strogatz با n=10000 گره و با پارامتر m=400 بسازیم.
#
#   در ابتدا به بررسی چندین نمونه از این گراف می پردازیم و به ازای مقادیر ثابت گره و پارامتر تاثیر مقدار احتمال باز اتصال می پردازیم
# </p>

# In[28]:


get_ipython().run_line_magic('matplotlib', 'notebook')
watts_strogatz1 = nx.watts_strogatz_graph(20, 4, 0.8)
nx.draw_shell(watts_strogatz1, with_labels=True)

# In[30]:


get_ipython().run_line_magic('matplotlib', 'notebook')
watts_strogatz2 = nx.watts_strogatz_graph(20, 4, 0.1)
nx.draw_shell(watts_strogatz2, with_labels=True)

# <p dir="rtl">
#       با توجه به شکل گراف های رسم شده در نمودار بالا واضح است که با افزایش احتمال بازاتصال با فرض ثابت بودن پارامتر و تعداد گره ها تعداد یال های میان گره هایی که به هم نزدیک تر اند کمتر می شود و و به نوعی یال ها به صورت محیطی در دایره متشکل از چینش گراف ها نخواهند بود و چینش قطری خواهند گرفت
# </p>

# <p dir="rtl">
#  حال به سراغ ساخت ماتریس خواسته شده در صورت پرسش می رویم (P=0)
# </p>

# In[7]:


watts_strogatz3 = nx.watts_strogatz_graph(10000, 400, 0)

# <p dir="rtl">
#      از جمله ویژگی های خاص لایبرری  networkx در پایتون این است که سینتکس های مورد استفاده ای برا تحلیل های گرافی را در اختیار ما قرار می دهد مثل به دست آوردن آرایه نود ها و
#     فاصله میانگین و خوشه بندی و یال ها و ماتریس مجاورت گراف و......
#     که در بخش های بعدی ازین ابزار استفاده می کنیم
#
# </p>

# In[31]:


print(nx.nodes(watts_strogatz1))
print(nx.average_shortest_path_length(watts_strogatz1))
print(nx.edge_betweenness(watts_strogatz1))
print(nx.clustering(watts_strogatz1))
print(nx.adjacency_matrix(watts_strogatz1))
print(nx.average_clustering(watts_strogatz1))


# # Simulation 2

# <p dir='rtl'>
#     در این بخش از شبیه سازی از ما خواسته شده است که برای مقادیر مختلف احتمال بازاتصال نمودار فاصله میانگین و ضریب خوشه بندی میانگین را برحسب خاصیت مورد نظر در بازه مورد نظر رسم کنیم
#     برای رسم این نمودار اسکیل محور x ها را به صورت لگاریتمی تقسیم می کنیم تا شکلی مشابه شکل موجود در فایل پروژه شود
#     در تابعی که آن را کال می کنیم ورودی ها به ترتیب تعداد مراحل نمایش داده شده برنمودار و تعدادگره و پارامتر است
#
# </p>

# In[43]:


def plot_graph(n, x, y):
    bins = np.geomspace(1e-6, 1, num=n)
    cl = []
    pa = []
    for i in bins:
        watts_strogatz = nx.watts_strogatz_graph(x, y, i)
        cl.append(nx.average_clustering(watts_strogatz))
        pa.append(nx.average_shortest_path_length(watts_strogatz))

    fig = plt.figure(figsize=(8, 6), dpi=100)
    plt.ylabel(r"Clustering, Path Length")
    plt.xlabel(r"Rewiring Probability (p)")
    plt.semilogx(np.geomspace(1e-6, 1, n, endpoint=True), cl, 'o')
    plt.semilogx(np.geomspace(1e-6, 1, n, endpoint=True), pa, 'o', color='y')
    plt.legend(["Clustering", "Path Length"])
    plt.show()


# <p dir='rtl'>
#     به دلیل محاسبات سخت و پیچیده گراف خواسته شده را تنها با مقادیر خاصی از تعداد گره و پارامتر و تعداد مراحل رسم شده ترسیم می کنیم
#     هرچند که توابع سلول بالا توانایی پردازش گراف های بزرگتری از این مقادیر را دارا می باشند.
# </p>

# In[44]:


plot_graph(50, 100, 40)

# In[46]:


plot_graph(100, 200, 60)

# # Simulation 3
#

# <p dir='rtl'>
#      در این بخش از شبیه سازی از خواسته شده است که مقداری p* را به دست آوریم که مقدار بهینه احتمال بازاتصال نام دارد
#     منظور از احتمال باز اتصال بهینه این است که بتوانیم مقدار احتمال را به گونه ای تنظیم کنیم که ضریب خوشه بندی میانگین چندان کاهش نیافته باشد ولی فاصله میانگین به قدر کافی کم شده باشد در این صورت قانون جهان کوچک را در مورد گراف های  watts-strogatz پیاده سازی کرده ایم
# </p>

# <p dir='rtl'>
#
#   همان طور که متوجه می شویم به صورت شهودی واضح است که  نقطه p* مشخص است
#   با توجه به کدهایی که در بخش پنج استفاده نمودیم و با توجه به این که در نمودار اول p* مقداری در حدود ده به توان منفی دو و نمودار دوم چیزی در بازه بین ده توان منفی دو تا ده به توان منفی یک است
#   می توان از این مقادیر دربخش پنج استفاده نمود منتها با اعدادی که فرض کردیم در گراف با 10000 راس و چک کردن مسیر بین تمام 2 راس های ممکن بیشینه فاصله گراف چیزی در حدود ده شد که با تعداد افراد موجود در فانون جهان کوچک که شش نفر است مقداری متفاوت است
# </p>

# # Simulation 4

# در این بخش از ما خوسته شده است که گرافی با 20000 راس و هر راس دارای 100 یال را با استفاده از مدل configuration مدل سازی کنیم
# همچنین از ما خواسته شده است که یک یال را انتخاب کرده و احتمال این موضوع را یابیم که آن یال انتخاب نشده طوقه و ابر یال نباشد
# با استفاده از سینتکس های موجود در configuration_model

# In[3]:


q = nx.Graph(nx.configuration_model([100] * 20000))
q.remove_edges_from(nx.selfloop_edges(q))
print("number of configuration graph edges: " + str(nx.number_of_edges(nx.configuration_model([100] * 20000))))
print("number of new graph edges: " + str(nx.number_of_edges(q)))
print("Prob: " + str(nx.number_of_edges(nx.Graph(nx.configuration_model([100] * 20000))) / nx.number_of_edges(
    nx.configuration_model([100] * 20000))))


# <p dir='rtl'>
#
#   با توجه به این که یکی از ضعف های مدل مد نظر وجود طوقه یا ابریال است ولی محاسبات بالا نشان می دهد که احتمال نبود طوقه و یا ابریال در یک یال انتخاب شده
#   در مجموعه تمامی یال ها بسیار نزدیک به یک است پس می توان از وجود آن ها صرف نظر نمود
#
#
# </p>

# # Simulation 5

# <p dir='rtl'>
# برای بررسی پرسش شبیه سازی این بخش از تابع  graph maker  استفاده می کنیم که
# و آن را صد بار کال می کنیم تا ماتریس های مورد نظر ساخته شود.
#     در داخل تابع نیز از سینتکس expected_degree_graph استفاده می کنیم که با گرفتن دنباله درجات d گراف مد نظر سوال را می سازد
# </p>

# In[22]:


def graphMaker(n, d):
    g = nx.expected_degree_graph(d)
    degree3 = np.array([0.0 for i in range(n)])
    for i in range(n):
        degree3[i] = g.degree[i]
    return degree3


# In[24]:



# <p dir='rtl'>
#     با توجه به خروجی سلول بالا ما برای n و d  مقادیر 100و5 را فرض کردیم و پس از محاسبه میانگین دنباله درجات رئوس این گراف متوجه می شویم که میانگین دنباله درجات رئوس گراف کاملا مشابه مقداری درجاتی که ما فرض کردیم نمی شود




